<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>
        <?php

            switch ($page)
            {
                case "home":    echo "Home - ";
                                break;
                case "Login":   echo "Login - ";
                                break;
            }
            
        ?>
        Play San Andreas
    </title>

    <!-- Bootstrap CDN-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Custom CSS template -->
    <link rel="stylesheet" href="static/css/app.css">
    <!-- FontAwesome CDN -->
    <script src="https://kit.fontawesome.com/9abb522041.js"></script>
</head>
<body>
    <!-- Navbar -->
    <section class="navigation">
        <div class="nav-container">
            <div class="brand">
                <a href="#!"><img src="static/img/logo.png" alt="Play San Andreas"></a>
            </div>
            <nav>
                <div class="nav-mobile"><a id="nav-toggle" href="#!"><span></span></a></div>
                <ul class="nav-list">
                    <li>
                        <a href="index.php"><i class="fas fa-home"></i> Home</a>
                    </li>
                    <li>
                        <a href="#!"><i class="fas fa-comments"></i> Forums</a>
                    </li>
                    <!--li>
                        <a href="#!">Main</a>
                        <ul class="nav-dropdown">
                            <li>
                                <a href="#!">Dropdown 1</a>
                            </li>
                            <li>
                                <a href="#!">Dropdown 2</a>
                            </li>
                            <li>
                                <a href="#!">Dropdown 3</a>
                            </li>
                        </ul>
                    </li-->
                    <li>
                        <a href="#!"><i class="fas fa-shopping-cart"></i> Shop</a>
                    </li>
                    <li>
                        <a href="#!"><i class="fas fa-users"></i> Players Online</a>
                    </li>
                    <li>
                        <a href="#!"><i class="fas fa-gamepad"></i>  Server</a>
                    </li>
                    <li>
                        <a href="#!"><i class="fas fa-images"></i> Media</a>
                        <ul class="nav-dropdown">
                            <li>
                                <a href="#!"><i class="fas fa-user-shield"></i> Staff</a>
                            </li>
                            <li>
                                <a href="#!"><i class="fas fa-user"></i> Players</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </section>
    <!-- Carousel -->
    <div id="carousel-indicaters" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner carousel-polygon">
            <div class="carousel-item active">
            <img class="d-block w-100" src="static/img/slide_1.jpg" alt="PlaySA1">
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="static/img/slide_2.jpg" alt="PlaySA1">
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="static/img/slide_3.jpg" alt="PlaySA1">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carousel-indicaters" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel-indicaters" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>