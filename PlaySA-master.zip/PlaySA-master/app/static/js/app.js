// Preloader 

$(window).on('load', function() {
    $('#status').fadeOut(); 
    $('#preloader').delay(350).fadeOut('slow'); 
    $('body').delay(350).css({'overflow':'visible'});
})

// Scroll down to content.
$(document).ready(function () {
    $(function () {
        var currentURL = (document.URL);
        var page = currentURL.split("/")[3];
        if (page != "") {
            $('html, body').animate({
                scrollTop: $('#content_box').offset().top
            }, 900);
            return false;
        }
    });
});
// dashboard panel
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}