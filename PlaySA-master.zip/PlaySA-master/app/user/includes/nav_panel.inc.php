                <div id="n_panel">
                    <div class="topnav" id="myTopnav">
                        <a href="#home" class="active"><i class="fas fa-home"></i> Home</a>
                        <?php
                            if($_SESSION['Level'] > 0)
                            {
                        ?>
                            <a href="#home" class="float-right"><i class="fas fa-user-shield"></i> Admin Panel</a>
                        <?php
                            }
                        ?>
                        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                            <i class="fa fa-bars"></i>
                        </a>
                    </div>
                </div>