                        <div class="col-md-3">
                            <div class="list-group">
                                <button type="button" class="list-group-item list-group-item-action g_bactive">
                                    <i class="fas fa-tachometer-alt"></i> Dashboard
                                </button>
                                <button type="button" class="list-group-item list-group-item-action"><i class="fas fa-user-cog"></i> User Settings</button>
                                <button type="button" onclick="location.href='../config/logout.cfg';" class="list-group-item list-group-item-action"><i class="fas fa-sign-out-alt"></i> Logout</button>
                            </div>
                        </div>