<?php  
    session_start();
    include "../config/func.cfg.php";
    CheckForLogin();
    $page = "home";
    include "includes/header.inc.php";
?>
    <!-- Content -->
    <div class="container">
        <div class="col-xl-13">
            <div id="content_box">
                <div class="content_header">
                        <i class="fas fa-columns" style="color: #C3073F;"></i> Dashboard 
                </div>
                <!-- Panel start -->
                <?php
                    include "includes/nav_panel.inc.php";
                ?>
                <!-- Panel end -->
                <div id="dashboard">
                    <div class="row">
                        <!-- Side Panel Start -->
                        <?php
                            include "includes/side_panel.inc.php";
                        ?>
                        <!-- Side Panel End -->
                        <!-- Dashboard Content Start -->
                        <div id="dash_content">
                            <div class="dc_header">

                            </div>
                        </div>
                        <!-- Dashboard Content End -->
                        <div class="col-md-9"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
    include "includes/footer.inc.php";
?>