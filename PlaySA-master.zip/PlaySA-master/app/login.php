<?php  
    session_start();
    $page = "Login";
    include "config/func.cfg.php";
    include "includes/header.inc.php";
    $url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI] "; 
    if(isset($_SESSION['User']))
    {
        header("location: user/dashboard");
        exit();
    }

?>
    <!-- Content -->
    <div class="container">
        <div class="col-xl-13">
            <div id="content_box">
                <div class="content_header">
                    <i class="fas fa-sign-in-alt" style="color: #C3073F;"></i> Login 
                </div>
                <div id="login_form">
                    <?php
                        $empty = strpos($url, "empty");
                        $sql = strpos($url, "sql");
                        $nouser = strpos($url, "nouser");
                        $wpass = strpos($url, "wpass");
                        if($empty == true)
                        {
                    ?>
                        <div class="alert my-4 alert-danger alert-dismissible fade show" role="alert">
                            <strong>Error!</strong><br> Please fill up all the details.
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php
                        }
                        if($sql == true)
                        {
                    ?>
                        <div class="alert my-4 alert-danger alert-dismissible fade show" role="alert">
                            <strong>Error!</strong><br> Please try after some time.
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php
                        }
                        elseif($nouser == true)
                        {
                    ?>
                        <div class="alert my-4 alert-danger alert-dismissible fade show" role="alert">
                            <strong>Error!</strong> <br> Username/Password is wrong. 
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php
                        }
                        elseif($wpass == true)
                        {
                        ?>
                    <div class="alert my-4 alert-danger alert-dismissible fade show" role="alert">
                            <strong>Error!</strong> <br> The password that you entered did not matched our records. 
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php
                        }
                    ?>
                    <hr>
                    <form action="config/login.cfg" method="POST">
                        <div class="form-group">
                            <input type="text" class="form-control" id="login_username" name="yl_user" placeholder="Username">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" id="login_password" name="yl_pass" placeholder="Password">
                        </div>
                        <button type="submit" name="yl_submit" class="form-control btn btn-primary space_gs"><i class="fas fa-sign-in-alt"></i> Login</button>
                    </form>
                <div>
            </div>
        </div>
    </div>
<?php
    include "includes/footer.inc.php";
?>