<?php
    // Database variables
    $serverName = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "playsa.play-union.com";

    $conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);

    if(!$conn)
    {
        die("Mysql Error : ".mysqli_connect_error());
        exit();
    }
