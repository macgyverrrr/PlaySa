<?php
    function CheckForLogin() {
        if(!isset($_SESSION['User']))
        {
            header("location: ../index");
            exit();
        }
    }