<?php
    session_start();
    $user = $_SESSION['User'];
    require "dbh.cfg.php";
    $sql = "UPDATE `playersdata` SET `wOnline`=0 WHERE `PlayerName`=?;";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql))
    {
        header("location: ../login?error=sql");
        exit();
    }
    else
    {
        mysqli_stmt_bind_param($stmt, "s", $user);
        mysqli_stmt_execute($stmt);
    }
    session_destroy();
    header("location: ../login");
    exit();