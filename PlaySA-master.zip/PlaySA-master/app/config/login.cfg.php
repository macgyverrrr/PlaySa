<?php
    if(isset($_POST['yl_submit']))
    {
        require("dbh.cfg.php");
        $user = $_POST['yl_user'];
        $pass = $_POST['yl_pass'];
        $ip = $_SERVER['REMOTE_ADDR'];
        
        // empty check
        if(empty($user) || empty($pass))
        {
            header("location: ../login?error=empty");
            exit();
        }
        else 
        {
            $sql = "SELECT * FROM `playersdata` WHERE `PlayerName`=?;";
            $stmt = mysqli_stmt_init($conn);

            if(!mysqli_stmt_prepare($stmt, $sql))
            {
                header("location: ../login?error=sql");
                exit();
            }
            else 
            {
                mysqli_stmt_bind_param($stmt, "s", $user);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);

                if($data = mysqli_fetch_assoc($result))
                {
                    $npass = strtoupper(hash("whirlpool", $pass));
                    if($npass != $data['Password'])
                    {
                        header("location: ../login?error=wpass");
                        exit();
                    }
                    elseif ($npass == $data['Password'])
                    {
                        session_start();
                        $_SESSION['uID'] = $data['ID'];
                        $_SESSION['User'] = $data['PlayerName'];
                        $_SESSION['Level'] = $data['Level'];
                        $_SESSION['Premium'] = $data['Premium'];

                        $sql = "UPDATE `playersdata` SET `wOnline`=1, `wLastLogin`=? WHERE `PlayerName`=?;";
                        $stmt = mysqli_stmt_init($conn);
                        
                        if(!mysqli_stmt_prepare($stmt, $sql))
                        {
                            header("location: ../login?error=sql");
                            exit();
                        }
                        else
                        {
                            mysqli_stmt_bind_param($stmt, "ss", $ip, $user);
                            mysqli_stmt_execute($stmt);
                        }
                        header("location: ../user/dashboard");
                        exit();
                    }
                    else 
                    {
                        header("location: ../login?error=wpass");
                        exit();
                    }
                }
                else
                {
                    header("location: ../login?error=nouser");
                    exit();
                }
            }
            mysqli_stmt_close($stmt);
            mysqli_close($conn);
        }

    }
    else
    {
        header("location: ../login");
        exit();
    }