<?php  
    $page = "home";
    include "includes/header.inc.php";
?>
    <!-- Content -->
    <div class="container">
        <div class="col-xl-13">
            <div id="content_box">
            
            </div>
        </div>
    </div>
<?php
    include "includes/footer.inc.php";
?>